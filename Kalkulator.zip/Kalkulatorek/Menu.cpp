#include "Menu.h"

void Menu::Polish(){
	cout << "Operatory wykonawcze:" << endl;
	cout << "+ -> sumowanie" << endl;
	cout << "- -> odejmowanie" << endl;
	cout << "* -> mnozenie" << endl;
	cout << "/ -> dzielenie" << endl;
	cout << "^ -> potegowanie" << endl;
	cout << "v -> pierwiastkowanie" << endl;
	cout << "Dzialanie nalezy wpisac po spacji dla przykladu: 7 + 9" << endl;
	cout << "------------------------------------------------------" << endl;
}
void Menu::English() {
	cout << "Operators:" << endl;
	cout << "+ -> Sum" << endl;
	cout << "- -> Difference" << endl;
	cout << "* -> Product" << endl;
	cout << "/ -> Quotient" << endl;
	cout << "^ -> Power" << endl;
	cout << "v -> Element" << endl;
	cout << "The action myst be entered with space for example: 7 + 9" << endl;
	cout << "--------------------------------------------------------" << endl;
}
bool Menu::Language() {
	cout << "Write: 0 -> English, 1 -> Polish" << endl;
	string x;
	cin >> x;
	if (x == "1") { system("CLS"); return true; }
	else { system("CLS"); return false; }
}
bool Menu::Exit() {
	cout << "To exit press ESC or press ENTER to continue" << endl;
	int x = _getch();
	if (x == 27) {
		system("CLS");
		return false;
	}
	else {
		system("CLS");
		return true;
	}
}
void Menu::WelcomeP() {
	system("Color 09");
	cout << "Witaj w mojej prostej aplikacji konsolowej!" << endl;
	cout << "Tworca: Marcin Pianka\nNumer indexu: 259534\nProwadzaca projekt: Mgr in\276. Kamila Organi\230ciak\n" << endl;
	cout << "Nacisnij dowolny przycisk aby kontynuowac!";
	int z = _getch();
	system("Color 07");
	system("CLS");
}
void Menu::WelcomeE() {
	system("Color 09");
	cout << "Welcome to my simply consol aplication!" << endl;
	cout << "Owner: Marcin Pianka\nIndex number: 259534\nLeading the project: Mgr in\276. Kamila Organi\230ciak\n" << endl;
	cout << "Press any button to continue!";
	int z = _getch();
	system("Color 07");
	system("CLS");
}