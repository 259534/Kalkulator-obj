#include <iostream>
#include "Kalkulator.h"
#include "Menu.h"

using namespace std;

bool Use,Use1;

int main()
{
	Calculator x;
	Menu y;
	Use = y.Language();
	if (Use)y.WelcomeP();
	else y.WelcomeE();
	for (;;)
	{
		if (Use) { 
			y.Polish(); 
			x.PreviousP(); 
			x.SetP(); 
		}
		else { 
			y.English(); 
			x.PreviousE(); 
			x.SetE(); 
		}
		Use1 = x.Look();
		if (Use1 && Use) {
			x.Chose();
			cout << x.GetP() << endl;
			
		}
		else if (Use1 && !Use) {
			x.Chose();
			cout << x.GetE() << endl;
		}
		if (!y.Exit())break;
	}
}

