#pragma once
#include <iostream>
#include <cmath>

using namespace std;

class Calculator
{
private:
	double first, second,score;
	char character;
	int previous = 0;
public:
	void SetP();
	double GetP();
	void SetE();
	double GetE();
	void Sum();
	void Difference();
	void Product();
	void Quotient();
	void Power();
	void Element();
	void PreviousP();
	void PreviousE();
	void Chose();
	bool Look();
};


