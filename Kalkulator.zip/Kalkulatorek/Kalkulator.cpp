#include "Kalkulator.h"

void Calculator::SetP()
{
	if (previous == 0)previous++;
	cout << "Wpisz dzialanie: ";
	cin >> first >> character >> second;
}
double Calculator::GetP()
{
	cout << "Wynik: ";
	return score;
}
void Calculator::SetE()
{
	if (previous == 0)previous++;
	cout << "Write your action: ";
	cin >> first >> character >> second;
}
double Calculator::GetE()
{
	cout << "Result: ";
	return score;
}
void Calculator::Sum() {
	score = first + second;
}
void Calculator::Difference() {
	score = first - second;
}
void Calculator::Product() {
	score = first * second;
}
void Calculator::Quotient() {
	score = first / second;
}
void Calculator::Power() {
	score = pow(first, second);
}
void Calculator::Element() {
		
	score = pow(first, 1/second);
}
void Calculator::Chose() {
	if (character == '+')Sum();
	else if (character == '-')Difference();
	else if (character == '*')Product();
	else if (character == '/')Quotient();
	else if (character == '^')Power();
	else if (character == 'v')Element();
}
bool Calculator::Look() {
	if ((character == '/' || character == 'v') && second == 0) {
		cout << "You can't dived by 0!" << endl;
		return false; 
	}
	else return true;
}
void Calculator::PreviousP() {
	if (previous > 0 && (character == '/' || character == 'v') && second == 0) {
		cout << "Twoje poprzednie dzialanie: " << first << " " << character << " " << second << " = " << "ERROR" << endl;
		cout << "--------------------------------------------------------" << endl;
	}
	else if (previous > 0) {
		cout << "Twoje poprzednie dzialanie: " << first << " " << character << " " << second << " = " << score << endl;
		cout << "--------------------------------------------------------" << endl;
	}
}
void Calculator::PreviousE() {
	if (previous > 0 && (character == '/' || character == 'v') && second == 0) {
		cout << "Your previous action: " << first << " " << character << " " << second << " = " << "ERROR" << endl;
		cout << "--------------------------------------------------------" << endl;
	}
	else if (previous > 0) {
		cout << "Your previous action: " << first << " " << character << " " << second << " = " << score << endl;
		cout << "--------------------------------------------------------" << endl;
	}
}

