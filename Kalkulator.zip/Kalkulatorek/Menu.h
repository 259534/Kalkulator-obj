#pragma once
#include <iostream>
#include <stdlib.h>
#include <conio.h>

using namespace std;
class Menu
{
public:
	void WelcomeP();
	void WelcomeE();
	void Polish();
	void English();
	bool Language();
	bool Exit();
};

